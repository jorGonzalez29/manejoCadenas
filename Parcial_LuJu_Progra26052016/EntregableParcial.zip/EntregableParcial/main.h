#ifndef MAIN_H
#define MAIN_H
#include <stdio.h>
#include <string.h>

#include "decodificar.h"
#include "lista.h"

#define ELIMINADOS "eliminados.txt"



#endif // MAIN_H
