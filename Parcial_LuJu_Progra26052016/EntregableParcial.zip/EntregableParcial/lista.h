#ifndef LISTA_H
#define LISTA_H

#include <stdlib.h>
#include <stdio.h>


typedef struct
{
    int             di,
                    me,
                    an;
} t_fecha;

typedef struct
{
    char            clave[9];
    char            desc[31];
    int             cilindrada;
    t_fecha         fecIng;
    double          importe;
} t_info;

typedef struct s_nodo
{
    t_info          info;
    struct s_nodo  *sig;
} t_nodo, *t_lista;

void crearLista(t_lista *p);
void mostrarLista(const t_lista *p);
void eliminarUnicos_2(t_lista *p, FILE *fp);
void cargarListaConValoresIniciales(t_lista *p);

#endif // LISTA_H
