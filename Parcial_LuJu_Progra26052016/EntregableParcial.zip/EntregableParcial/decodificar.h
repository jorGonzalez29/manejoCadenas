#ifndef DECODIFICAR_H
#define DECODIFICAR_H

char *decodificar_2(char *cad);

/** resuelva y utilice su propia versi�n con el nombre :  */


#endif // DECODIFICAR_H
