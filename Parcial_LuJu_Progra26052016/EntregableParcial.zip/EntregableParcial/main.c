#include "main.h"


int main(void)
{
    char     cadena[] = { "3SZL49994" };
    t_lista  lista;
    FILE    *fpSal = fopen(ELIMINADOS, "wt");

/** punto 1 */
    printf("Antes   : \"%s\"\n", cadena);
    decodificar_2(cadena);
    printf("Despues : \"%s\"\n", cadena);
/**/

    if(fpSal == NULL)
    {
        fprintf(stderr,
                "ERROR - creando archivo \"%s\" en modo \"wt\"\n",
                ELIMINADOS);
        exit(1);
    }
    crearLista(&lista);
/** la siguientes funciones cargan informaci�n en la lista, la muestran,
 *      eliminan los nodos que la fecha y cilindrada es �nica y la vuelven
 *      a mostrar
 */
    cargarListaConValoresIniciales(&lista);
    mostrarLista(&lista);
    /** debe hacer su propia versi�n de la siguiente funci�n */
    eliminarUnicos_2(&lista, fpSal);

    mostrarLista(&lista);
    fclose(fpSal);
    return 0;
}
